#include "blurEffect.h"


QImage BlurEffect::blurImage(QImage source, int blurRadius)
{
    if(source.isNull()) return QImage();

    QGraphicsScene scene;
    QGraphicsPixmapItem item;
    item.setPixmap(QPixmap::fromImage(source));

    auto *blur = new QGraphicsBlurEffect;
    blur->setBlurRadius(blurRadius);
    item.setGraphicsEffect(blur);
    scene.addItem(&item);
    QImage result(source.size(), QImage::Format_ARGB32);
    result.fill(Qt::transparent);
    QPainter painter(&result);
    scene.render(&painter, QRectF(),
                 QRectF(0, 0, source.width(), source.height()));
    return result;
}

void BlurEffect::getImage(QString sourceFile)
{
    auto blured = blurImage(QImage(sourceFile), blurRadius);
    imageLabel->setPixmap(QPixmap::fromImage(blured).scaled(
        imageLabel->width(),
        imageLabel->height(), Qt::KeepAspectRatio));
}

void BlurEffect::getRadius(int newValue)
{
    blurRadius = newValue;
    getImage(filePath);
}

void BlurEffect::openImage()
{
    filePath = QFileDialog::getOpenFileName(nullptr,
                                            "Open picture",
                                            ":/",
                                            "jpg files (*.jpg)");
    getImage(filePath);

}

void BlurEffect::saveImage()
{
    QString fileDir;
    QString fileName;

    for(auto str : qAsConst(filePath))
    {
        if(str == "/")
            fileName = nullptr;
        else
            fileName += str;
    }

    int i = 0;
    for(auto str : qAsConst(filePath))
    {
        ++i;
        fileDir += str;
        if(i == filePath.length() - fileName.length()) break;
    }

    fileName = "blured_" + fileName;
    auto blured = blurImage(QImage(filePath), blurRadius);
    blured.save(fileDir + fileName);
};
