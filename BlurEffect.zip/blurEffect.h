#ifndef BLUREFFECT_H
#define BLUREFFECT_H

#include <QApplication>
#include <QMainWindow>
#include <QPushButton>
#include <QSlider>
#include <QLabel>
#include <QGraphicsScene>
#include <QGraphicsBlurEffect>
#include <QGraphicsPixmapItem>
#include <QImage>
#include <QPainter>
#include <QFileDialog>

class BlurEffect : public QMainWindow
{
    Q_OBJECT

public:
    QLabel *imageLabel = nullptr;
    QSlider *slider = nullptr;

    BlurEffect(QWidget *parent = nullptr) : QMainWindow(parent) {}

    QImage blurImage(QImage source, int blurRadius);
    void getImage(QString sourceFile);
    void getRadius(int newValue);
    void openImage();
    void saveImage();

public slots:
    void Open() { openImage(); };
    void Save() { saveImage(); };

private:
    QString filePath;
    QImage source;
    int blurRadius;
};
#endif // BLUREFFECT_H
