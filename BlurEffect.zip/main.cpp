#include "blurEffect.h"
#include "./ui_blurEffect.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    BlurEffect blurEffect(nullptr);
    Ui::BlurEffect ui;
    ui.setupUi(&blurEffect);

    blurEffect.imageLabel = ui.imageLabel;
    blurEffect.imageLabel->setMinimumSize(640, 450);
    blurEffect.slider = ui.slider;

    QSlider *slider = blurEffect.slider;
    slider->setRange(0, 10);
    slider->setValue(1);

    QObject::connect(slider, &QSlider::valueChanged, [&slider, &blurEffect](int newValue)
    {
        blurEffect.getRadius(newValue);
    });

    blurEffect.show();
    return a.exec();
}
