#ifndef IMAGEBUTTON_H
#define IMAGEBUTTON_H

#include <QApplication>
#include <QPushButton>
#include <QPixmap>
#include <QPainter>
#include <QPaintEvent>
#include <QTimer>
#include <QSoundEffect>


class ImageButton : public QPushButton
{
    Q_OBJECT
public:
    ImageButton(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *e) override;
    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;
    void keyPressEvent(QKeyEvent *e) override;

public slots:
    void setUp();
    void setDown();

private:
    QPixmap mCurrentButtonPixmap;
    QPixmap mButtonDownPixmap;
    QPixmap mButtonUpPixmap;
    bool isDown = false;
};

#endif // IMAGEBUTTON_H
