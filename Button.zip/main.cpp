#include "imageButton.h"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    ImageButton redButton(nullptr);
    redButton.setFixedSize(150, 150);
    redButton.move(500, 400);

    QSoundEffect* myEffectPlayer = new QSoundEffect{};
    myEffectPlayer->setSource(QUrl::fromLocalFile(":/sample.wav"));
    myEffectPlayer->setVolume(1.f);

    QObject::connect(&redButton, &QPushButton::clicked, myEffectPlayer, &QSoundEffect::play);
    redButton.show();
    return a.exec();
}
